import { loginByUsername, logout } from '@/service/getData'
import { getToken, setToken, removeToken } from '@/utils/auth'

const user = {
  state: {
    user: '',
    status: '',
    code: '',
    token: getToken(),
    name: getToken('Admin-Token'),
    avatar: '',
    introduction: '',
    roles: '',
    setting: {
      articlePlatform: []
    }
  },

  mutations: {
    SET_CODE: (state, code) => {
      state.code = code
    },
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_INTRODUCTION: (state, introduction) => {
      state.introduction = introduction
    },
    SET_SETTING: (state, setting) => {
      state.setting = setting
    },
    SET_STATUS: (state, status) => {
      state.status = status
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    }
  },

  actions: {
    // 用户名登录
    LoginByUsername({ commit }, userInfo) {
      return new Promise((resolve, reject) => {
        loginByUsername(userInfo).then(response => {
	    		commit('SET_NAME', userInfo.username);
	    		commit('SET_TOKEN', userInfo.username);
	    		setToken('Admin-Token',userInfo.username);
	        resolve(response)
        }).catch(error => {
          reject(error)
        })
      })
    },
    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        logout(state.token).then((data) => {
          commit('SET_TOKEN', '')
          commit('SET_ROLES', [])
          removeToken('Admin-Token')
          resolve(data)
        }).catch(error => {
          reject(error)
        })
      })
    }
  }
}

export default user
