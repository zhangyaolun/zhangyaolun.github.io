// translate router.meta.title, be used in breadcrumb sidebar tagsview
export function generateTitle(title) {
	console.log(title)
  return title
}
