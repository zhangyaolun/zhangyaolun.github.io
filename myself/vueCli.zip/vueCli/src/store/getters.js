export default {
	count:function(state){
        return state.count +=100;
    }
}